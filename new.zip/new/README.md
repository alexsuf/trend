# TREND Platform - Минимальный деплой на kubeadm

## Структура каталога

```
new/
├── deploy.ps1                 <- ОДНА команда для деплоя (Windows)
├── deploy.sh                  <- ОДНА команда для деплоя (Linux/Ubuntu)
├── docker/                    <- Dockerfile'ы
│   ├── Dockerfile.trend       (Flask + Worker)
│   └── Dockerfile.adm         (Admin Panel)
├── app/                       <- Код приложения
│   ├── app.py, models.py, pipeline.py, worker.py ...
│   └── templates/
├── adm/                       <- Код админки
│   ├── adm.py, models.py, config.py ...
│   └── templates/
├── k8s/                       <- Kubernetes манифесты (20 файлов)
│   ├── *-namespace.yaml
│   ├── keycloak-postgres-*
│   ├── keycloak-*
│   ├── searxng-*
│   ├── flask-*
│   ├── adm-*
│   └── worker-*
└── sql/                       <- SQL для инициализации базы
    ├── base.sql               (полный pg_dump схемы)
    └── 001-init-schema.sql    (ручной DDL)
```

## Быстрый старт

### 1. Подготовка кластера

```bash
# На ВМ в облаке (Ubuntu 24.04):
# kubeadm, kubectl, kubelet и Docker должны быть установлены заранее

sudo kubeadm init --pod-network-cidr=10.244.0.0/16
mkdir -p $HOME/.kube
sudo cp /etc/kubernetes/admin.conf $HOME/.kube/config

kubectl apply -f https://github.com/flannel-io/flannel/releases/latest/download/kube-flannel.yml
kubectl taint nodes --all node-role.kubernetes.io/control-plane-
kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/main/deploy/static/provider/cloud/deploy.yaml

docker run -d -p 5000:5000 --restart=always --name registry registry:2
```

### 2. Деплой

**Windows (PowerShell):**
```powershell
cd new
$env:REGISTRY='localhost:5000'; $env:INGRESS_IP='10.111.129.2'; .\deploy.ps1
```

**Linux/Ubuntu (bash):**
```bash
cd new
export REGISTRY='localhost:5000'
export INGRESS_IP='10.111.129.2'
./deploy.sh
```

### 3. Проверить

```bash
kubectl get pods -A | grep -E 'trend|keycloak|search'
```

### 4. DNS / hosts

```bash
INGRESS_IP=$(hostname -I | awk '{print $1}')
echo "$INGRESS_IP web.trend-app adm.trend-app auth.trend-app search.local" | sudo tee -a /etc/hosts
```

### 5. Настройка Keycloak

1. `http://auth.trend-app` -> Administration Console -> `admin/secret`
2. Create realm: `trend`
3. Clients -> Create:
   - `trend-web`, secret: `bbWGIugaSj9ithjybqoNR5hXI9acjEel`
   - Redirect: `http://web.trend-app/*`
4. Clients -> Create:
   - `trend-admin`, secret: `ZePGCk9losJjuOtQxBLcHK64RgAF5MfNDaqpnS7b3V`
   - Redirect: `http://adm.trend-app/*`
5. Realm roles: `admin`
6. Users -> Add user with role `admin`

### 6. Настройка LLM через админку

1. `http://adm.trend-app` -> войти как админ
2. Провайдеры -> создать (Bothub, OpenAI, etc.)
3. Модели -> добавить gpt-4o-mini
4. Группы LLM -> создать
5. Модели групп -> привязать модель к группе (default)
6. Пользователи в группах -> добавить пользователя

### 7. Готово

`http://web.trend-app` -> можно создавать запросы.

## Что нужно заполнить перед запуском

1. В `deploy.ps1` (Windows) или `deploy.sh` (Linux) при необходимости поменяйте значения по умолчанию для `REGISTRY` и `INGRESS_IP`.
2. В `new/k8s/flask-deployment.yaml`, `new/k8s/adm-deployment.yaml` и `new/k8s/worker-deployment.yaml` проверьте `hostAliases`, если у вас другой IP ingress или другой адрес кластера.
3. В `new/k8s/searxng-settings.yaml` поменяйте `base_url`, если SearXNG будет открываться не с `http://localhost:8080/`.
4. В `new/app/config.json` и `new/adm/config.py` поменяйте секреты и client secret, если хотите не использовать dev-значения.
5. В `new/llm/setup-keycloak.sh` обновите redirect URI, если будете запускать настройку Keycloak отдельно.

## Как запускать на другой машине

1. Установите Docker, `kubectl` и доступ к Kubernetes-кластеру.
2. Запустите локальный registry или укажите внешний `REGISTRY`.
3. Настройте `hosts` на новой машине для `web.trend-app`, `adm.trend-app`, `auth.trend-app`.
4. Выполните:
   - Windows: `.\deploy.ps1`
   - Linux/Ubuntu: `./deploy.sh`
5. После завершения откройте `http://auth.trend-app`, затем `http://adm.trend-app`, потом `http://web.trend-app`.

## Переменные

| Переменная | Назначение | По умолчанию |
|---|---|---|
| `REGISTRY` | Docker registry | `localhost:5000` |
| `INGRESS_IP` | IP ingress-контроллера | автоопределение |
