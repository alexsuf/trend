-- ============================================================
-- TREND Platform — полный DDL для пустой базы данных
-- PostgreSQL 17+
-- Применение: psql -U keycloak -d trend < 001-init-schema.sql
-- ============================================================

-- Расширение для gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;

-- ============================================================
-- ENUM
-- ============================================================
DO $$ BEGIN
    CREATE TYPE task_status AS ENUM ('queued', 'running', 'analyzing', 'formatting', 'done', 'error');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- ============================================================
-- Последовательности
-- ============================================================
CREATE SEQUENCE IF NOT EXISTS users_user_number_seq              START 1;
CREATE SEQUENCE IF NOT EXISTS research_tasks_task_number_seq      START 1;
CREATE SEQUENCE IF NOT EXISTS research_reports_report_number_seq  START 1;
CREATE SEQUENCE IF NOT EXISTS agent_events_event_number_seq      START 1;
CREATE SEQUENCE IF NOT EXISTS llm_providers_provider_number_seq   START 1;
CREATE SEQUENCE IF NOT EXISTS llm_models_model_number_seq         START 1;
CREATE SEQUENCE IF NOT EXISTS llm_fallback_relation_number_seq    START 1;
CREATE SEQUENCE IF NOT EXISTS llm_groups_group_number_seq         START 1;
CREATE SEQUENCE IF NOT EXISTS user_groups_relation_number_seq     START 1;
CREATE SEQUENCE IF NOT EXISTS group_models_relation_number_seq    START 1;
CREATE SEQUENCE IF NOT EXISTS agent_models_relation_number_seq    START 1;

-- ============================================================
-- Таблицы
-- ============================================================

-- 1. users
CREATE TABLE users (
    id              UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_number     BIGINT UNIQUE DEFAULT nextval('users_user_number_seq'::regclass),
    keycloak_id     TEXT UNIQUE NOT NULL,
    username        TEXT,
    email           TEXT,
    is_admin        BOOLEAN NOT NULL DEFAULT FALSE,
    is_analyst      BOOLEAN NOT NULL DEFAULT FALSE,
    created_at      TIMESTAMP DEFAULT now()
);
CREATE INDEX idx_users_keycloak_id ON users(keycloak_id);
CREATE INDEX idx_users_username ON users(username);

-- 2. llm_providers
CREATE TABLE llm_providers (
    id              UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    provider_number BIGINT UNIQUE DEFAULT nextval('llm_providers_provider_number_seq'::regclass),
    name            TEXT UNIQUE NOT NULL,
    provider_type   TEXT NOT NULL,
    base_url        TEXT NOT NULL,
    api_key         TEXT,
    enabled         BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMP DEFAULT now()
);

-- 3. llm_models
CREATE TABLE llm_models (
    id              UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    model_number    BIGINT UNIQUE DEFAULT nextval('llm_models_model_number_seq'::regclass),
    provider_id     UUID NOT NULL REFERENCES llm_providers(id) ON DELETE CASCADE,
    model_name      TEXT NOT NULL,
    display_name    TEXT,
    context_size    INTEGER,
    max_tokens      INTEGER,
    temperature     NUMERIC(3,2),
    enabled         BOOLEAN NOT NULL DEFAULT TRUE,
    priority        INTEGER NOT NULL DEFAULT 100,
    timeout         INTEGER NOT NULL DEFAULT 180,
    created_at      TIMESTAMP DEFAULT now(),
    UNIQUE(provider_id, model_name)
);
CREATE INDEX idx_llm_models_provider_id ON llm_models(provider_id);

-- 4. llm_groups
CREATE TABLE llm_groups (
    id              UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    group_number    BIGINT UNIQUE DEFAULT nextval('llm_groups_group_number_seq'::regclass),
    name            TEXT UNIQUE NOT NULL,
    description     TEXT,
    enabled         BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMP DEFAULT now()
);

-- 5. user_groups
CREATE TABLE user_groups (
    id              UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    relation_number BIGINT UNIQUE DEFAULT nextval('user_groups_relation_number_seq'::regclass),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    group_id        UUID NOT NULL REFERENCES llm_groups(id) ON DELETE CASCADE,
    created_at      TIMESTAMP DEFAULT now(),
    UNIQUE(user_id, group_id)
);
CREATE INDEX idx_user_groups_user_id ON user_groups(user_id);
CREATE INDEX idx_user_groups_group_id ON user_groups(group_id);

-- 6. group_models
CREATE TABLE group_models (
    id              UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    relation_number BIGINT UNIQUE DEFAULT nextval('group_models_relation_number_seq'::regclass),
    group_id        UUID NOT NULL REFERENCES llm_groups(id) ON DELETE CASCADE,
    model_id        UUID NOT NULL REFERENCES llm_models(id) ON DELETE CASCADE,
    is_default      BOOLEAN NOT NULL DEFAULT FALSE,
    created_at      TIMESTAMP DEFAULT now()
);
CREATE INDEX idx_group_models_group_id ON group_models(group_id);
CREATE INDEX idx_group_models_model_id ON group_models(model_id);

-- 7. llm_fallback
CREATE TABLE llm_fallback (
    id              UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    relation_number BIGINT UNIQUE DEFAULT nextval('llm_fallback_relation_number_seq'::regclass),
    model_id        UUID NOT NULL REFERENCES llm_models(id) ON DELETE CASCADE,
    fallback_model_id UUID NOT NULL REFERENCES llm_models(id) ON DELETE CASCADE,
    priority        INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX idx_llm_fallback_model_id ON llm_fallback(model_id);

-- 8. agent_models
CREATE TABLE agent_models (
    id              UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    relation_number BIGINT UNIQUE DEFAULT nextval('agent_models_relation_number_seq'::regclass),
    agent_name      TEXT UNIQUE NOT NULL,
    model_id        UUID NOT NULL REFERENCES llm_models(id) ON DELETE CASCADE,
    created_at      TIMESTAMP DEFAULT now()
);

-- 9. research_tasks
CREATE TYPE task_status AS ENUM ('queued', 'running', 'analyzing', 'formatting', 'done', 'error');

CREATE TABLE research_tasks (
    id              UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    task_number     BIGINT UNIQUE DEFAULT nextval('research_tasks_task_number_seq'::regclass),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    prompt          TEXT NOT NULL,
    status          task_status NOT NULL DEFAULT 'queued',
    priority        BIGINT DEFAULT 0,
    model_used      TEXT,
    meta            JSONB,
    error_message   TEXT,
    logs            JSONB,
    created_at      TIMESTAMP DEFAULT now(),
    started_at      TIMESTAMP,
    finished_at     TIMESTAMP
);
CREATE INDEX idx_research_tasks_user_id ON research_tasks(user_id);
CREATE INDEX idx_research_tasks_status ON research_tasks(status);
CREATE INDEX idx_research_tasks_created_at ON research_tasks(created_at);

-- 10. research_reports
CREATE TABLE research_reports (
    id              UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    report_number   BIGINT UNIQUE DEFAULT nextval('research_reports_report_number_seq'::regclass),
    task_id         UUID NOT NULL UNIQUE REFERENCES research_tasks(id) ON DELETE CASCADE,
    report_json     JSONB NOT NULL,
    sources         JSONB,
    score           INTEGER DEFAULT 0,
    created_at      TIMESTAMP DEFAULT now()
);
CREATE INDEX idx_research_reports_task_id ON research_reports(task_id);

-- 11. agent_events
CREATE TABLE agent_events (
    id              UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    event_number    BIGINT UNIQUE DEFAULT nextval('agent_events_event_number_seq'::regclass),
    task_id         UUID NOT NULL REFERENCES research_tasks(id) ON DELETE CASCADE,
    agent_name      TEXT NOT NULL,
    event_type      TEXT NOT NULL,
    message         TEXT,
    meta            JSONB,
    elapsed_seconds NUMERIC(10,2),
    created_at      TIMESTAMP DEFAULT now()
);
CREATE INDEX idx_agent_events_task_id ON agent_events(task_id);
CREATE INDEX idx_agent_events_created_at ON agent_events(created_at);

-- 12. research_scores
CREATE TABLE research_scores (
    score           INTEGER PRIMARY KEY,
    color           TEXT NOT NULL
);

-- ============================================================
-- Начальные данные
-- ============================================================
INSERT INTO research_scores (score, color) VALUES
    (5,   '#555555'),
    (8,   '#e67e22'),
    (100, '#1a6b2a')
ON CONFLICT (score) DO NOTHING;

-- ============================================================
-- Права
-- ============================================================
GRANT ALL ON ALL TABLES IN SCHEMA public TO trend;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO trend;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO trend;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO trend;
