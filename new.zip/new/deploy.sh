#!/bin/bash
set -e
# ============================================================
# TREND Platform — One-command deployment for kubeadm cloud
# Uses pre-built images from Docker Hub
# ============================================================
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
K8S_DIR="$SCRIPT_DIR/k8s"

# ─── Настройки ───
INGRESS_IP="${INGRESS_IP:-}"  # IP ingress-контроллера (определится автоматически)

echo "========================================"
echo "  TREND Platform — Kubeadm Deployment"
echo "========================================"

# 1. Обнаружение IP ingress-контроллера
if [ -z "$INGRESS_IP" ]; then
    INGRESS_IP=$(kubectl get svc -n ingress-nginx ingress-nginx-controller -o jsonpath='{.spec.clusterIP}' 2>/dev/null || echo "")
    if [ -z "$INGRESS_IP" ]; then
        INGRESS_IP=$(kubectl get nodes -o jsonpath='{.items[0].status.addresses[?(@.type=="InternalIP")].address}' 2>/dev/null || echo "127.0.0.1")
    fi
fi
echo "  Ingress IP: $INGRESS_IP"

# 2. Используем готовые образа с Docker Hub (никакой сборки не требуется)
echo "[1/4] Using pre-built images from Docker Hub..."
echo "  Images: alexsuf/trend:latest, alexsuf/trend-adm:latest"

# 3. Применение Kubernetes манифестов
echo "[2/4] Applying Kubernetes manifests..."

# Namespaces
kubectl apply -f "$K8S_DIR/keycloak-namespace.yaml"
kubectl apply -f "$K8S_DIR/search-namespace.yaml"
kubectl apply -f "$K8S_DIR/trend-namespace.yaml"

# PostgreSQL
kubectl apply -f "$K8S_DIR/keycloak-postgres-pvc.yaml"
kubectl apply -f "$K8S_DIR/keycloak-postgres-deployment.yaml"
kubectl apply -f "$K8S_DIR/keycloak-postgres-service.yaml"
kubectl apply -f "$K8S_DIR/postgres-nodeport.yaml"

echo "  Waiting for PostgreSQL..."
kubectl wait --for=condition=ready pod -l app=postgres -n keycloak --timeout=120s

# Init DB
kubectl apply -f "$K8S_DIR/init-trend-db.yaml"
sleep 5

# Apply base SQL schema
echo "  Applying base.sql..."
POSTGRES_POD=$(kubectl get pods -n keycloak -l app=postgres -o jsonpath='{.items[0].metadata.name}')
kubectl exec -n keycloak "$POSTGRES_POD" -- psql -U keycloak -d trend -f /dev/stdin < "$SCRIPT_DIR/sql/base.sql" 2>/dev/null || echo "  base.sql applied (warnings ignored)"
echo "  Schema created"

# Keycloak + SearXNG (parallel)
kubectl apply -f "$K8S_DIR/keycloak-deployment.yaml"
kubectl apply -f "$K8S_DIR/keycloak-service.yaml"
kubectl apply -f "$K8S_DIR/keycloak-ingress.yaml"

kubectl apply -f "$K8S_DIR/searxng-settings.yaml"
kubectl apply -f "$K8S_DIR/searxng-deployment.yaml"
kubectl apply -f "$K8S_DIR/searxng-service.yaml"
kubectl apply -f "$K8S_DIR/searxng-ingress.yaml"

echo "  Waiting for Keycloak + SearXNG..."
kubectl wait --for=condition=ready pod -l app=keycloak -n keycloak --timeout=180s 2>/dev/null || true
kubectl wait --for=condition=ready pod -l app=searxng  -n search   --timeout=120s 2>/dev/null || true

# Application layer — используем готовые образа из Docker Hub
apply_app() {
    sed "s|10\.111\.129\.2|$INGRESS_IP|g; s|10\.109\.173\.27|$INGRESS_IP|g" "$1" | \
    sed "s|image: alexsuf/trend$|image: alexsuf/trend:latest|g; s|image: alexsuf/trend-adm$|image: alexsuf/trend-adm:latest|g" | \
    sed "s|imagePullPolicy: Never|imagePullPolicy: Always|g" | \
    kubectl apply -f -
}

apply_app "$K8S_DIR/flask-deployment.yaml"
kubectl apply -f "$K8S_DIR/flask-service.yaml"
kubectl apply -f "$K8S_DIR/flask-ingress.yaml"

apply_app "$K8S_DIR/adm-deployment.yaml"
kubectl apply -f "$K8S_DIR/adm-service.yaml"
kubectl apply -f "$K8S_DIR/adm-ingress.yaml"

apply_app "$K8S_DIR/worker-deployment.yaml"

# 4. Проверка
echo "[3/4] Checking pods..."
sleep 10
kubectl get pods -n keycloak
kubectl get pods -n search
kubectl get pods -n trend

echo ""
echo "========================================"
echo "  DEPLOYMENT COMPLETE"
echo "========================================"
echo ""
echo "  Добавьте в /etc/hosts:"
echo "  $INGRESS_IP web.trend-app adm.trend-app auth.trend-app search.local"
echo ""
echo "  Порядок действий после деплоя:"
echo "  1. http://auth.trend-app  — настроить Keycloak (realm=trend, clients)"
echo "  2. http://adm.trend-app   — добавить провайдера LLM, модель, группу"
echo "  3. http://web.trend-app   — можно работать"