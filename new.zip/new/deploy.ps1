$ErrorActionPreference = 'Stop'

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$K8sDir = Join-Path $ScriptDir 'k8s'
$AppDir = Join-Path $ScriptDir 'app'
$AdmDir = Join-Path $ScriptDir 'adm'
$DockerDir = Join-Path $ScriptDir 'docker'
$SqlDir = Join-Path $ScriptDir 'sql'

$Registry = if ($env:REGISTRY) { $env:REGISTRY } else { 'localhost:5000' }
$IngressIp = $env:INGRESS_IP

Write-Host '========================================'
Write-Host '  TREND Platform - Kubernetes Deploy'
Write-Host '========================================'

if ([string]::IsNullOrWhiteSpace($IngressIp)) {
    $nodeIp = (kubectl get nodes -o jsonpath='{.items[0].status.addresses[?(@.type=="InternalIP")].address}' 2>$null)
    if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($nodeIp)) {
        $IngressIp = '127.0.0.1'
    } else {
        $IngressIp = $nodeIp.Trim()
    }
}

Write-Host "Ingress IP: $IngressIp"
Write-Host "Registry:   $Registry"

Write-Host '[1/4] Building Docker images...'
docker build -t "$Registry/trend:latest" -f (Join-Path $DockerDir 'Dockerfile.trend') $AppDir
docker build -t "$Registry/trend-adm:latest" -f (Join-Path $DockerDir 'Dockerfile.adm') $AdmDir

Write-Host '[2/4] Pushing Docker images...'
docker push "$Registry/trend:latest"
docker push "$Registry/trend-adm:latest"

function Apply-YamlFile {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    Get-Content -LiteralPath $Path | ForEach-Object {
        $_ -replace '10\.111\.129\.2', $IngressIp `
           -replace '10\.109\.173\.27', $IngressIp `
           -replace 'image: alexsuf/trend$', "image: $Registry/trend:latest" `
           -replace 'image: alexsuf/trend-adm$', "image: $Registry/trend-adm:latest" `
           -replace 'imagePullPolicy: Never', 'imagePullPolicy: Always'
    } | kubectl apply -f -
}

Write-Host '[3/4] Applying Kubernetes manifests...'
kubectl apply -f (Join-Path $K8sDir 'keycloak-namespace.yaml')
kubectl apply -f (Join-Path $K8sDir 'search-namespace.yaml')
kubectl apply -f (Join-Path $K8sDir 'trend-namespace.yaml')

kubectl apply -f (Join-Path $K8sDir 'keycloak-postgres-pvc.yaml')
kubectl apply -f (Join-Path $K8sDir 'keycloak-postgres-deployment.yaml')
kubectl apply -f (Join-Path $K8sDir 'keycloak-postgres-service.yaml')
kubectl apply -f (Join-Path $K8sDir 'postgres-nodeport.yaml')

Write-Host 'Waiting for PostgreSQL...'
kubectl wait --for=condition=ready pod -l app=postgres -n keycloak --timeout=180s

kubectl apply -f (Join-Path $K8sDir 'init-trend-db.yaml')
Start-Sleep -Seconds 5

Write-Host 'Applying base.sql...'
$PostgresPod = (kubectl get pods -n keycloak -l app=postgres -o jsonpath='{.items[0].metadata.name}')
Get-Content -LiteralPath (Join-Path $SqlDir 'base.sql') | kubectl exec -i -n keycloak $PostgresPod -- psql -U keycloak -d trend

kubectl apply -f (Join-Path $K8sDir 'keycloak-deployment.yaml')
kubectl apply -f (Join-Path $K8sDir 'keycloak-service.yaml')
kubectl apply -f (Join-Path $K8sDir 'keycloak-ingress.yaml')

kubectl apply -f (Join-Path $K8sDir 'searxng-settings.yaml')
kubectl apply -f (Join-Path $K8sDir 'searxng-deployment.yaml')
kubectl apply -f (Join-Path $K8sDir 'searxng-service.yaml')
kubectl apply -f (Join-Path $K8sDir 'searxng-ingress.yaml')

Write-Host 'Waiting for Keycloak and SearXNG...'
kubectl wait --for=condition=ready pod -l app=keycloak -n keycloak --timeout=180s 2>$null | Out-Null
kubectl wait --for=condition=ready pod -l app=searxng -n search --timeout=180s 2>$null | Out-Null

Apply-YamlFile -Path (Join-Path $K8sDir 'flask-deployment.yaml')
kubectl apply -f (Join-Path $K8sDir 'flask-service.yaml')
kubectl apply -f (Join-Path $K8sDir 'flask-ingress.yaml')

Apply-YamlFile -Path (Join-Path $K8sDir 'adm-deployment.yaml')
kubectl apply -f (Join-Path $K8sDir 'adm-service.yaml')
kubectl apply -f (Join-Path $K8sDir 'adm-ingress.yaml')

Apply-YamlFile -Path (Join-Path $K8sDir 'worker-deployment.yaml')

Write-Host '[4/4] Final checks...'
Start-Sleep -Seconds 10
kubectl get pods -n keycloak
kubectl get pods -n search
kubectl get pods -n trend

Write-Host ''
Write-Host '========================================'
Write-Host '  DEPLOYMENT COMPLETE'
Write-Host '========================================'
Write-Host ''
Write-Host 'Add to hosts file:'
Write-Host "$IngressIp web.trend-app adm.trend-app auth.trend-app search.local"
Write-Host ''
Write-Host 'Next steps:'
Write-Host '  1. http://auth.trend-app  - Keycloak admin console (admin/secret)'
Write-Host '  2. http://adm.trend-app   - configure providers, models, groups'
Write-Host '  3. http://web.trend-app   - start using the app'
