--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: task_status; Type: TYPE; Schema: public; Owner: trend
--

CREATE TYPE public.task_status AS ENUM (
    'queued',
    'running',
    'analyzing',
    'formatting',
    'done',
    'error'
);


ALTER TYPE public.task_status OWNER TO trend;

--
-- Name: taskstatus; Type: TYPE; Schema: public; Owner: trend
--

CREATE TYPE public.taskstatus AS ENUM (
    'queued',
    'running',
    'analyzing',
    'formatting',
    'done',
    'error'
);


ALTER TYPE public.taskstatus OWNER TO trend;

--
-- Name: agent_events_event_number_seq; Type: SEQUENCE; Schema: public; Owner: trend
--

CREATE SEQUENCE public.agent_events_event_number_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agent_events_event_number_seq OWNER TO trend;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agent_events; Type: TABLE; Schema: public; Owner: trend
--

CREATE TABLE public.agent_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    event_number bigint DEFAULT nextval('public.agent_events_event_number_seq'::regclass),
    task_id uuid NOT NULL,
    agent_name text NOT NULL,
    event_type text NOT NULL,
    message text,
    meta jsonb,
    elapsed_seconds numeric(10,2),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.agent_events OWNER TO trend;

--
-- Name: agent_models; Type: TABLE; Schema: public; Owner: trend
--

CREATE TABLE public.agent_models (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    relation_number bigint NOT NULL,
    agent_name text NOT NULL,
    model_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.agent_models OWNER TO trend;

--
-- Name: agent_models_relation_number_seq; Type: SEQUENCE; Schema: public; Owner: trend
--

CREATE SEQUENCE public.agent_models_relation_number_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agent_models_relation_number_seq OWNER TO trend;

--
-- Name: agent_models_relation_number_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: trend
--

ALTER SEQUENCE public.agent_models_relation_number_seq OWNED BY public.agent_models.relation_number;


--
-- Name: group_models; Type: TABLE; Schema: public; Owner: trend
--

CREATE TABLE public.group_models (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    relation_number bigint NOT NULL,
    group_id uuid NOT NULL,
    model_id uuid NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.group_models OWNER TO trend;

--
-- Name: group_models_relation_number_seq; Type: SEQUENCE; Schema: public; Owner: trend
--

CREATE SEQUENCE public.group_models_relation_number_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.group_models_relation_number_seq OWNER TO trend;

--
-- Name: group_models_relation_number_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: trend
--

ALTER SEQUENCE public.group_models_relation_number_seq OWNED BY public.group_models.relation_number;


--
-- Name: llm_fallback; Type: TABLE; Schema: public; Owner: trend
--

CREATE TABLE public.llm_fallback (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    relation_number bigint NOT NULL,
    model_id uuid NOT NULL,
    fallback_model_id uuid NOT NULL,
    priority integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.llm_fallback OWNER TO trend;

--
-- Name: llm_fallback_relation_number_seq; Type: SEQUENCE; Schema: public; Owner: trend
--

CREATE SEQUENCE public.llm_fallback_relation_number_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llm_fallback_relation_number_seq OWNER TO trend;

--
-- Name: llm_fallback_relation_number_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: trend
--

ALTER SEQUENCE public.llm_fallback_relation_number_seq OWNED BY public.llm_fallback.relation_number;


--
-- Name: llm_groups; Type: TABLE; Schema: public; Owner: trend
--

CREATE TABLE public.llm_groups (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    group_number bigint NOT NULL,
    name text NOT NULL,
    description text,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.llm_groups OWNER TO trend;

--
-- Name: llm_groups_group_number_seq; Type: SEQUENCE; Schema: public; Owner: trend
--

CREATE SEQUENCE public.llm_groups_group_number_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llm_groups_group_number_seq OWNER TO trend;

--
-- Name: llm_groups_group_number_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: trend
--

ALTER SEQUENCE public.llm_groups_group_number_seq OWNED BY public.llm_groups.group_number;


--
-- Name: llm_models; Type: TABLE; Schema: public; Owner: trend
--

CREATE TABLE public.llm_models (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    model_number bigint NOT NULL,
    provider_id uuid NOT NULL,
    model_name text NOT NULL,
    display_name text,
    context_size integer,
    max_tokens integer,
    temperature numeric(3,2),
    enabled boolean DEFAULT true NOT NULL,
    priority integer DEFAULT 100 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    timeout integer DEFAULT 180 NOT NULL
);


ALTER TABLE public.llm_models OWNER TO trend;

--
-- Name: llm_models_model_number_seq; Type: SEQUENCE; Schema: public; Owner: trend
--

CREATE SEQUENCE public.llm_models_model_number_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llm_models_model_number_seq OWNER TO trend;

--
-- Name: llm_models_model_number_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: trend
--

ALTER SEQUENCE public.llm_models_model_number_seq OWNED BY public.llm_models.model_number;


--
-- Name: llm_providers; Type: TABLE; Schema: public; Owner: trend
--

CREATE TABLE public.llm_providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_number bigint NOT NULL,
    name text NOT NULL,
    provider_type text NOT NULL,
    base_url text NOT NULL,
    api_key text,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.llm_providers OWNER TO trend;

--
-- Name: llm_providers_provider_number_seq; Type: SEQUENCE; Schema: public; Owner: trend
--

CREATE SEQUENCE public.llm_providers_provider_number_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llm_providers_provider_number_seq OWNER TO trend;

--
-- Name: llm_providers_provider_number_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: trend
--

ALTER SEQUENCE public.llm_providers_provider_number_seq OWNED BY public.llm_providers.provider_number;


--
-- Name: research_reports; Type: TABLE; Schema: public; Owner: trend
--

CREATE TABLE public.research_reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    report_number bigint NOT NULL,
    task_id uuid NOT NULL,
    report_json jsonb NOT NULL,
    sources jsonb,
    score integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.research_reports OWNER TO trend;

--
-- Name: research_reports_report_number_seq; Type: SEQUENCE; Schema: public; Owner: trend
--

CREATE SEQUENCE public.research_reports_report_number_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.research_reports_report_number_seq OWNER TO trend;

--
-- Name: research_reports_report_number_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: trend
--

ALTER SEQUENCE public.research_reports_report_number_seq OWNED BY public.research_reports.report_number;


--
-- Name: research_scores; Type: TABLE; Schema: public; Owner: trend
--

CREATE TABLE public.research_scores (
    score integer NOT NULL,
    color text
);
INSERT INTO research_scores (score, color) VALUES (5, '#555555');
INSERT INTO research_scores (score, color) VALUES (8, '#e67e22');
INSERT INTO research_scores (score, color) VALUES (100, '#1a6b2a');

ALTER TABLE public.research_scores OWNER TO trend;

--
-- Name: research_tasks; Type: TABLE; Schema: public; Owner: trend
--

CREATE TABLE public.research_tasks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    task_number bigint NOT NULL,
    user_id uuid NOT NULL,
    prompt text NOT NULL,
    status text DEFAULT 'queued'::text NOT NULL,
    priority integer DEFAULT 0,
    model_used text,
    error_message text,
    created_at timestamp without time zone DEFAULT now(),
    started_at timestamp without time zone,
    finished_at timestamp without time zone,
    meta jsonb DEFAULT '{}'::jsonb,
    logs jsonb DEFAULT '[]'::jsonb
);


ALTER TABLE public.research_tasks OWNER TO trend;

--
-- Name: research_tasks_task_number_seq; Type: SEQUENCE; Schema: public; Owner: trend
--

CREATE SEQUENCE public.research_tasks_task_number_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.research_tasks_task_number_seq OWNER TO trend;

--
-- Name: research_tasks_task_number_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: trend
--

ALTER SEQUENCE public.research_tasks_task_number_seq OWNED BY public.research_tasks.task_number;


--
-- Name: user_groups; Type: TABLE; Schema: public; Owner: trend
--

CREATE TABLE public.user_groups (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    relation_number bigint NOT NULL,
    user_id uuid NOT NULL,
    group_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_groups OWNER TO trend;

--
-- Name: user_groups_relation_number_seq; Type: SEQUENCE; Schema: public; Owner: trend
--

CREATE SEQUENCE public.user_groups_relation_number_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_groups_relation_number_seq OWNER TO trend;

--
-- Name: user_groups_relation_number_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: trend
--

ALTER SEQUENCE public.user_groups_relation_number_seq OWNED BY public.user_groups.relation_number;


--
-- Name: users; Type: TABLE; Schema: public; Owner: trend
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_number bigint NOT NULL,
    keycloak_id text NOT NULL,
    username text,
    email text,
    created_at timestamp without time zone DEFAULT now(),
    is_admin boolean DEFAULT false NOT NULL,
    is_analyst boolean DEFAULT false NOT NULL
);


ALTER TABLE public.users OWNER TO trend;

--
-- Name: users_user_number_seq; Type: SEQUENCE; Schema: public; Owner: trend
--

CREATE SEQUENCE public.users_user_number_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_user_number_seq OWNER TO trend;

--
-- Name: users_user_number_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: trend
--

ALTER SEQUENCE public.users_user_number_seq OWNED BY public.users.user_number;


--
-- Name: agent_models relation_number; Type: DEFAULT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.agent_models ALTER COLUMN relation_number SET DEFAULT nextval('public.agent_models_relation_number_seq'::regclass);


--
-- Name: group_models relation_number; Type: DEFAULT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.group_models ALTER COLUMN relation_number SET DEFAULT nextval('public.group_models_relation_number_seq'::regclass);


--
-- Name: llm_fallback relation_number; Type: DEFAULT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.llm_fallback ALTER COLUMN relation_number SET DEFAULT nextval('public.llm_fallback_relation_number_seq'::regclass);


--
-- Name: llm_groups group_number; Type: DEFAULT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.llm_groups ALTER COLUMN group_number SET DEFAULT nextval('public.llm_groups_group_number_seq'::regclass);


--
-- Name: llm_models model_number; Type: DEFAULT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.llm_models ALTER COLUMN model_number SET DEFAULT nextval('public.llm_models_model_number_seq'::regclass);


--
-- Name: llm_providers provider_number; Type: DEFAULT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.llm_providers ALTER COLUMN provider_number SET DEFAULT nextval('public.llm_providers_provider_number_seq'::regclass);


--
-- Name: research_reports report_number; Type: DEFAULT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.research_reports ALTER COLUMN report_number SET DEFAULT nextval('public.research_reports_report_number_seq'::regclass);


--
-- Name: research_tasks task_number; Type: DEFAULT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.research_tasks ALTER COLUMN task_number SET DEFAULT nextval('public.research_tasks_task_number_seq'::regclass);


--
-- Name: user_groups relation_number; Type: DEFAULT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.user_groups ALTER COLUMN relation_number SET DEFAULT nextval('public.user_groups_relation_number_seq'::regclass);


--
-- Name: users user_number; Type: DEFAULT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.users ALTER COLUMN user_number SET DEFAULT nextval('public.users_user_number_seq'::regclass);


--
-- Name: agent_events agent_events_event_number_key; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.agent_events
    ADD CONSTRAINT agent_events_event_number_key UNIQUE (event_number);


--
-- Name: agent_events agent_events_pkey; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.agent_events
    ADD CONSTRAINT agent_events_pkey PRIMARY KEY (id);


--
-- Name: agent_models agent_models_agent_name_key; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.agent_models
    ADD CONSTRAINT agent_models_agent_name_key UNIQUE (agent_name);


--
-- Name: agent_models agent_models_pkey; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.agent_models
    ADD CONSTRAINT agent_models_pkey PRIMARY KEY (id);


--
-- Name: agent_models agent_models_relation_number_key; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.agent_models
    ADD CONSTRAINT agent_models_relation_number_key UNIQUE (relation_number);


--
-- Name: group_models group_models_group_id_model_id_key; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.group_models
    ADD CONSTRAINT group_models_group_id_model_id_key UNIQUE (group_id, model_id);


--
-- Name: group_models group_models_pkey; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.group_models
    ADD CONSTRAINT group_models_pkey PRIMARY KEY (id);


--
-- Name: group_models group_models_relation_number_key; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.group_models
    ADD CONSTRAINT group_models_relation_number_key UNIQUE (relation_number);


--
-- Name: llm_fallback llm_fallback_model_id_fallback_model_id_key; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.llm_fallback
    ADD CONSTRAINT llm_fallback_model_id_fallback_model_id_key UNIQUE (model_id, fallback_model_id);


--
-- Name: llm_fallback llm_fallback_pkey; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.llm_fallback
    ADD CONSTRAINT llm_fallback_pkey PRIMARY KEY (id);


--
-- Name: llm_fallback llm_fallback_relation_number_key; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.llm_fallback
    ADD CONSTRAINT llm_fallback_relation_number_key UNIQUE (relation_number);


--
-- Name: llm_groups llm_groups_group_number_key; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.llm_groups
    ADD CONSTRAINT llm_groups_group_number_key UNIQUE (group_number);


--
-- Name: llm_groups llm_groups_name_key; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.llm_groups
    ADD CONSTRAINT llm_groups_name_key UNIQUE (name);


--
-- Name: llm_groups llm_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.llm_groups
    ADD CONSTRAINT llm_groups_pkey PRIMARY KEY (id);


--
-- Name: llm_models llm_models_model_number_key; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.llm_models
    ADD CONSTRAINT llm_models_model_number_key UNIQUE (model_number);


--
-- Name: llm_models llm_models_pkey; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.llm_models
    ADD CONSTRAINT llm_models_pkey PRIMARY KEY (id);


--
-- Name: llm_models llm_models_provider_id_model_name_key; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.llm_models
    ADD CONSTRAINT llm_models_provider_id_model_name_key UNIQUE (provider_id, model_name);


--
-- Name: llm_providers llm_providers_name_key; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.llm_providers
    ADD CONSTRAINT llm_providers_name_key UNIQUE (name);


--
-- Name: llm_providers llm_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.llm_providers
    ADD CONSTRAINT llm_providers_pkey PRIMARY KEY (id);


--
-- Name: llm_providers llm_providers_provider_number_key; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.llm_providers
    ADD CONSTRAINT llm_providers_provider_number_key UNIQUE (provider_number);


--
-- Name: research_reports research_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.research_reports
    ADD CONSTRAINT research_reports_pkey PRIMARY KEY (id);


--
-- Name: research_reports research_reports_report_number_key; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.research_reports
    ADD CONSTRAINT research_reports_report_number_key UNIQUE (report_number);


--
-- Name: research_reports research_reports_task_id_key; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.research_reports
    ADD CONSTRAINT research_reports_task_id_key UNIQUE (task_id);


--
-- Name: research_tasks research_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.research_tasks
    ADD CONSTRAINT research_tasks_pkey PRIMARY KEY (id);


--
-- Name: research_tasks research_tasks_task_number_key; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.research_tasks
    ADD CONSTRAINT research_tasks_task_number_key UNIQUE (task_number);


--
-- Name: user_groups user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.user_groups
    ADD CONSTRAINT user_groups_pkey PRIMARY KEY (id);


--
-- Name: user_groups user_groups_relation_number_key; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.user_groups
    ADD CONSTRAINT user_groups_relation_number_key UNIQUE (relation_number);


--
-- Name: user_groups user_groups_user_id_group_id_key; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.user_groups
    ADD CONSTRAINT user_groups_user_id_group_id_key UNIQUE (user_id, group_id);


--
-- Name: users users_keycloak_id_key; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_keycloak_id_key UNIQUE (keycloak_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_user_number_key; Type: CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_user_number_key UNIQUE (user_number);


--
-- Name: idx_research_tasks_created_at; Type: INDEX; Schema: public; Owner: trend
--

CREATE INDEX idx_research_tasks_created_at ON public.research_tasks USING btree (created_at DESC);


--
-- Name: idx_research_tasks_status; Type: INDEX; Schema: public; Owner: trend
--

CREATE INDEX idx_research_tasks_status ON public.research_tasks USING btree (status);


--
-- Name: idx_research_tasks_user_id; Type: INDEX; Schema: public; Owner: trend
--

CREATE INDEX idx_research_tasks_user_id ON public.research_tasks USING btree (user_id);


--
-- Name: agent_events agent_events_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.agent_events
    ADD CONSTRAINT agent_events_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.research_tasks(id) ON DELETE CASCADE;


--
-- Name: agent_models agent_models_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.agent_models
    ADD CONSTRAINT agent_models_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.llm_models(id) ON DELETE CASCADE;


--
-- Name: research_tasks fk_user; Type: FK CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.research_tasks
    ADD CONSTRAINT fk_user FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: group_models group_models_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.group_models
    ADD CONSTRAINT group_models_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.llm_groups(id) ON DELETE CASCADE;


--
-- Name: group_models group_models_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.group_models
    ADD CONSTRAINT group_models_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.llm_models(id) ON DELETE CASCADE;


--
-- Name: llm_fallback llm_fallback_fallback_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.llm_fallback
    ADD CONSTRAINT llm_fallback_fallback_model_id_fkey FOREIGN KEY (fallback_model_id) REFERENCES public.llm_models(id) ON DELETE CASCADE;


--
-- Name: llm_fallback llm_fallback_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.llm_fallback
    ADD CONSTRAINT llm_fallback_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.llm_models(id) ON DELETE CASCADE;


--
-- Name: llm_models llm_models_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.llm_models
    ADD CONSTRAINT llm_models_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.llm_providers(id) ON DELETE CASCADE;


--
-- Name: research_reports research_reports_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.research_reports
    ADD CONSTRAINT research_reports_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.research_tasks(id) ON DELETE CASCADE;


--
-- Name: research_tasks research_tasks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.research_tasks
    ADD CONSTRAINT research_tasks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_groups user_groups_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.user_groups
    ADD CONSTRAINT user_groups_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.llm_groups(id) ON DELETE CASCADE;


--
-- Name: user_groups user_groups_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trend
--

ALTER TABLE ONLY public.user_groups
    ADD CONSTRAINT user_groups_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Заполнение данными
--


